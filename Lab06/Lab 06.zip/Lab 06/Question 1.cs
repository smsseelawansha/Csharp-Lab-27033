﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp1
{
    class MainClass
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the size of the array:");
            int arraySize = int.Parse(Console.ReadLine());

            Arrinputclass arrayInputClass = new Arrinputclass();
            int[] array = arrayInputClass.CreateArrayWithZeroes(arraySize);

            Console.WriteLine("Enter the elements of the array:");
            arrayInputClass.InputArray(array);

            Console.WriteLine("Array with 0s after each input value:");
            arrayInputClass.PrintArray(array);
            Console.ReadLine();
        }
    }
}
    

