﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp1
{
    internal class Arrinputclass
    {
        public int[] CreateArrayWithZeroes(int arraySize)
        {
            return new int[arraySize * 2];
        }

        public void InputArray(int[] array)
        {
            for (int i = 0; i < array.Length; i += 2)
            {
                int input = int.Parse(Console.ReadLine());
                array[i] = input;
                array[i + 1] = 0;
            }
        }

        public void PrintArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }
        }
    }
}
