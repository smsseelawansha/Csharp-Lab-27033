﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Get the input from the user.
            Console.WriteLine("Enter the number");
            int number = int.Parse(Console.ReadLine());
            int sum = 0;

            for (int i = 0; number > 0; i++)
            {
                int digit = number % 10;
                sum += digit;
                number /= 10;
            }

            Console.WriteLine("Sum of digits " + sum);
            Console.ReadKey();
        }
    }
}
    

