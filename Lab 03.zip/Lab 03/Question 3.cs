﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Get the input from the user.
            Console.WriteLine("Enter the number");
            int n = int.Parse(Console.ReadLine());
            int sum = 1;

            for (int i = 3; i <= n; i += 2)
            {
                sum += i;
            }

            Console.WriteLine("Sum of odd numbers: " + sum);
            Console.ReadKey();
        }
    }
}
    

