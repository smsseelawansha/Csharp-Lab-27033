﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Check 10 numbers that if the numbers are even or odd.
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Enter a number");
                int num = int.Parse(Console.ReadLine());
                if (num % 2 == 0)
                {
                    Console.WriteLine("even\n");
                }
                else
                {
                    Console.WriteLine("odd\n");
                }
            }
            Console.ReadKey();
        }
    }
}
    

