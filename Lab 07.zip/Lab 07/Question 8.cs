﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalDog
{
    class Animal
    {
        public void AnimalMethod()
        {
            Console.WriteLine("I am Animal");
        }
    }

    class Dog : Animal
    {
        public void DogMethod()
        {
            Console.WriteLine("I have four legs");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Creating an Animal:");
            Animal animal = new Animal();
            animal.AnimalMethod();

            Console.WriteLine("\nCreating a Dog:");
            Dog dog = new Dog();
            dog.AnimalMethod();
            dog.DogMethod();
            Console.ReadLine(); 
        }
    }
}


