﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Get a value from the user.
            Console.WriteLine("Enter a number");
            int num = int.Parse(Console.ReadLine());

            // Check if the number is even or odd.
            if (num % 2 == 0)
            {
                Console.WriteLine("even");
            }
            else
            {
                Console.WriteLine("odd");
            }
            Console.ReadKey();
        }
    }
}
    

