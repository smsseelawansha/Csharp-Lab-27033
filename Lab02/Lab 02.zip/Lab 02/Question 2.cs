﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Get the radiusfrom the user.
            Console.WriteLine("Enter the radius");
            float radius = float.Parse(Console.ReadLine());

            // Calculate the area and circumference of the circle.
            float area = 22/7 * radius * radius;
            float circumference = 2 * 22/7 * radius;

            // Display the results to the user.
            Console.WriteLine("The area of the circle is " + area);
            Console.WriteLine("The circumference of the circle is " + circumference);
            Console.ReadKey();
        }
    }
}
    

