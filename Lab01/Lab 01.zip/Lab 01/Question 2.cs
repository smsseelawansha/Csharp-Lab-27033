﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Read the name and batch from the user.
            Console.WriteLine("Enter your name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter your name");
            string batch = Console.ReadLine();

            // Print the name and batch to the console.
            Console.WriteLine("Welcome " + name + " and your batch is " + batch);
            Console.ReadKey();
        }
    }
}
    

