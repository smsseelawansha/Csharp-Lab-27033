﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Get the salary and tax rate from the user.
            Console.WriteLine("Enter the salary");
            float salary = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter the tax rate %");
            float trate = float.Parse(Console.ReadLine());

            // Calculate the after tax salary.
            float nsalary = salary - (salary * trate / 100);

            // Print the salary after the tax to the console.
            Console.WriteLine("The salary after the tax " + nsalary);
            Console.ReadKey();
        }
    }
}
    

