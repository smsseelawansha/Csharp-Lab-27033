﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoleapp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Get the input values from the user.
            Console.WriteLine("Enter a number");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a number");
            int num2 = int.Parse(Console.ReadLine());

            // Calculate the summation of the two input values.
            int sum = num1 + num2;

            // Print the summation to the console.
            Console.WriteLine("The summation is " + sum);
            Console.ReadKey();
        }
    }
}
    

