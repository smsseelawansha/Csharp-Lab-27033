﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            FindValues calculator = new FindValues();

            Console.Write("Radius: ");
            double r = double.Parse(Console.ReadLine());

            double area = calculator.FindArea(r);
            Console.WriteLine("\nArea: " + area);

            double circumference = calculator.FindCircumference(r);
            Console.WriteLine("\nCircumference: " + circumference);

            Console.ReadLine();
        }
    }
}
