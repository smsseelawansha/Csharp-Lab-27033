﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_2
{
    internal class FindValues
    {
        //Finding the area
        public double FindArea(double r)
        {
            double area = Math.PI * r * r;
            return area;
        }

        //Finding the circumference
        public double FindCircumference(double r)
        {
            double circumference = 2 * Math.PI * r;
            return circumference;
        }
    }
}
