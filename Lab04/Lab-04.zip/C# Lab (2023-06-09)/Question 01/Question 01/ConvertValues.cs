﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_01
{
    internal class ConvertValues
    {
        public void KilometerToMeter()
        {
            Console.Write("Distance(Km): ");
            double km1 = double.Parse(Console.ReadLine());

            double m1 = km1 * 1000;
            Console.WriteLine("Distance(M): " + m1);
        }

        public void KilometerToMeter(double km2)
        {
            double m2 = km2 * 1000;
            Console.WriteLine("Distance(M): " + m2);
        }

        public double KilometerToMeterWithReturn(double km3)
        {
            double m2 = km3 * 1000;
            return m2;
        }
    }
}
