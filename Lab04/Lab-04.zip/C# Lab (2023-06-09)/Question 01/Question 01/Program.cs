﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ConvertValues converter = new ConvertValues();

            //No return type No Parameter Method
            converter.KilometerToMeter();

            //No return type with parameter method
            Console.Write("\nDistance(Km): ");
            double km2 = double.Parse(Console.ReadLine());
            converter.KilometerToMeter(km2);

            //With return type with parameter method
            Console.Write("\nDistance(Km): ");
            double km3 = double.Parse(Console.ReadLine());
            double m3 = converter.KilometerToMeterWithReturn(km3);
            Console.WriteLine("Distance(M): " + m3);

            Console.ReadLine();
        }
    }
}
