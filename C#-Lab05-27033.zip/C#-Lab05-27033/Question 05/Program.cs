using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace HelloWorld
{
	public class Program
	{
		public static void Main(string[] args)
		{
			  int[] array = new int[10];

        Console.WriteLine("Enter 10 numbers:");

        for (int i = 0; i < array.Length; i++)
        {
            array[i] = Convert.ToInt32(Console.ReadLine());
        }

        ArrayOperations arrayOperations = new ArrayOperations();
        int minimum = arrayOperations.FindMinimum(array);
        int maximum = arrayOperations.FindMaximum(array);
        double average = arrayOperations.FindAverage(array);
        int[] reversedArray = arrayOperations.ReverseArray(array);

        Console.WriteLine("Minimum value: " + minimum);
        Console.WriteLine("Maximum value: " + maximum);
        Console.WriteLine("Average value: " + average);
        Console.WriteLine("Reversed array: " + string.Join(", ", reversedArray));

        Console.ReadLine();
		}
	}
}