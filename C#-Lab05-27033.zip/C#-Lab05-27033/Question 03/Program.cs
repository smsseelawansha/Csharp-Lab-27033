using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace HelloWorld
{
	public class Program
	{
		public static void Main(string[] args)
		{
		    Console.WriteLine("Enter your choice:");
        Console.WriteLine("1. Addition");
        Console.WriteLine("2. Subtraction");
        Console.WriteLine("3. Multiplication");
        Console.WriteLine("4. Division");

        int choice = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Enter number 1:");
        int num1 = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Enter number 2:");
        int num2 = Convert.ToInt32(Console.ReadLine());

        CalculateValues calculator = new CalculateValues();

        int result = 0;

        switch (choice)
        {
            case 1:
                result = calculator.Addition(num1, num2);
                break;
            case 2:
                result = calculator.Subtraction(num1, num2);
                break;
            case 3:
                result = calculator.Multiplication(num1, num2);
                break;
            case 4:
                result = calculator.Division(num1, num2);
                break;
            default:
                Console.WriteLine("Invalid choice");
                break;
        }

        Console.WriteLine("Your answer: " + result);

        Console.ReadLine();
		}
	}
}