using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace HelloWorld
{
	public class HelloClass
  {
    public void SayHello()
    {
        Console.WriteLine("Hello, World!");
    }
  }
}