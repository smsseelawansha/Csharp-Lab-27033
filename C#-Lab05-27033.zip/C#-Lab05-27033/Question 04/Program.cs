using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace HelloWorld
{
	public class Program
	{
		public static void Main(string[] args)
		{
      HelloClass helloObject = new HelloClass();
      helloObject.SayHello();

      Console.ReadLine();
		}
	}
}